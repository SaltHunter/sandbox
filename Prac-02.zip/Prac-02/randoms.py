# 1. maximum of 20 minimum of 5

#2. 3 minimum 9 maximum, cant produce a 4

#3. a lot of decimals? , largest number is 5.5 smallest is 2.5